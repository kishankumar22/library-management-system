(()=>{var e={};e.id=673,e.ids=[673],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},16141:e=>{"use strict";e.exports=require("node:zlib")},19185:e=>{"use strict";e.exports=require("dgram")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31421:e=>{"use strict";e.exports=require("node:child_process")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37067:e=>{"use strict";e.exports=require("node:http")},37366:e=>{"use strict";e.exports=require("dns")},41204:e=>{"use strict";e.exports=require("string_decoder")},44708:e=>{"use strict";e.exports=require("node:https")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},48161:e=>{"use strict";e.exports=require("node:os")},48780:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>g,routeModule:()=>y,serverHooks:()=>O,workAsyncStorage:()=>f,workUnitAsyncStorage:()=>x});var s={};r.r(s),r.d(s,{GET:()=>l,POST:()=>I,PUT:()=>m});var a=r(96559),n=r(48088),o=r(37719),i=r(32190),u=r(56285),d=r(79743),p=r(16332),c=r.n(p);async function l(){try{let e=await (0,u.X)(),t=await e.request().query(`
      SELECT 
        p.PenaltyId,
        p.IssueId,
        p.Amount,
        CASE 
          WHEN p.Amount <= COALESCE(SUM(lp.AmountPaid), 0) THEN 'paid'
          ELSE 'unpaid'
        END AS PenaltyStatus,
        p.CreatedOn,
        p.CreatedBy,
        p.ModifiedBy,
        p.ModifiedOn,
        p.Remarks,
        bi.BookId,
        bi.StudentId,
        bi.IssueDate,
        bi.DueDate,
        bi.ReturnDate,
        bi.Status AS BookIssueStatus,
        bi.IsRenewed,
        b.Title AS BookTitle,
        s.fName + ' ' + s.lName AS StudentName,
        c.courseName,
        sad.courseYear,
        COALESCE(SUM(lp.AmountPaid), 0) AS TotalPaid
      FROM Penalty p WITH (NOLOCK)
      JOIN BookIssue bi WITH (NOLOCK) ON p.IssueId = bi.IssueId
      JOIN Books b WITH (NOLOCK) ON bi.BookId = b.BookId
      JOIN Student s WITH (NOLOCK) ON bi.StudentId = s.id
      JOIN Course c WITH (NOLOCK) ON s.courseId = c.id
      LEFT JOIN StudentAcademicDetails sad WITH (NOLOCK) ON s.id = sad.studentId
      LEFT JOIN LibraryPayment lp WITH (NOLOCK) ON p.IssueId = lp.IssueId
      GROUP BY 
        p.PenaltyId, p.IssueId, p.Amount, p.Status, p.CreatedOn, p.CreatedBy, 
        p.ModifiedBy, p.ModifiedOn, p.Remarks, bi.BookId, bi.StudentId, 
        bi.IssueDate, bi.DueDate, bi.ReturnDate, bi.Status, bi.IsRenewed, 
        b.Title, s.fName, s.lName, c.courseName, sad.courseYear
      ORDER BY p.CreatedOn DESC
    `);return i.NextResponse.json(t.recordset)}catch(e){return d.A.error("Error fetching penalties",{error:e.message,stack:e.stack}),i.NextResponse.json({message:"Error fetching penalties"},{status:500})}}async function m(e){try{let{searchParams:t}=new URL(e.url),r=t.get("id"),{Status:s}=await e.json();if(!r)return d.A.error("Penalty ID is required"),i.NextResponse.json({message:"Penalty ID is required"},{status:400});let a=await (0,u.X)(),n=await a.request().input("PenaltyId",c().Int,r).query("SELECT * FROM Penalty WITH (NOLOCK) WHERE PenaltyId = @PenaltyId");if(0===n.recordset.length)return d.A.error(`Penalty not found: ${r}`),i.NextResponse.json({message:"Penalty not found"},{status:404});return await a.request().input("PenaltyId",c().Int,r).input("Status",c().VarChar,s).input("ModifiedBy",c().NVarChar,"Kishan Kumar").input("ModifiedOn",c().DateTime,new Date).query(`
        UPDATE Penalty 
        SET Status = @Status, 
            ModifiedBy = @ModifiedBy, 
            ModifiedOn = @ModifiedOn
        WHERE PenaltyId = @PenaltyId
      `),d.A.info(`Penalty updated successfully: ${r}`),i.NextResponse.json({message:"Penalty updated successfully"})}catch(e){return d.A.error("Error updating penalty",{error:e.message,stack:e.stack}),i.NextResponse.json({message:"Error updating penalty"},{status:500})}}async function I(e){try{let{IssueId:t,StudentId:r,AmountPaid:s,PaymentMode:a,TransactionId:n,CreatedBy:o}=await e.json();if(!t||!r||!s||!a||!o)return d.A.error("Missing required fields for payment",{IssueId:t,StudentId:r,AmountPaid:s,PaymentMode:a}),i.NextResponse.json({message:"Missing required fields"},{status:400});let p=await (0,u.X)(),l=new(c()).Transaction(p);try{await l.begin(c().ISOLATION_LEVEL.SERIALIZABLE);let e=await p.request().input("IssueId",c().Int,t).query(`
          SELECT p.PenaltyId, p.Amount, COALESCE(SUM(lp.AmountPaid), 0) AS TotalPaid
          FROM Penalty p WITH (NOLOCK)
          LEFT JOIN LibraryPayment lp WITH (NOLOCK) ON p.IssueId = lp.IssueId
          WHERE p.IssueId = @IssueId
          GROUP BY p.PenaltyId, p.Amount
        `);if(0===e.recordset.length)return await l.rollback(),d.A.error(`Penalty not found for IssueId: ${t}`),i.NextResponse.json({message:"Penalty not found"},{status:404});let{PenaltyId:u,Amount:m,TotalPaid:I}=e.recordset[0],y=I+s;if(y>m)return await l.rollback(),d.A.error(`Payment exceeds penalty amount for IssueId: ${t}`),i.NextResponse.json({message:"Payment amount exceeds remaining penalty amount"},{status:400});return await l.request().input("IssueId",c().Int,t).input("StudentId",c().Int,r).input("AmountPaid",c().Float,s).input("PaymentMode",c().VarChar,a).input("TransactionId",c().VarChar,n||null).input("CreatedBy",c().NVarChar,o).input("CreatedOn",c().DateTime,new Date).query(`
          INSERT INTO LibraryPayment (StudentId, IssueId, AmountPaid, PaymentMode, TransactionId,  CreatedBy, CreatedOn)
          VALUES (@StudentId, @IssueId, @AmountPaid, @PaymentMode, @TransactionId, @CreatedBy, @CreatedOn)
        `),y>=m&&await l.request().input("PenaltyId",c().Int,u).input("Status",c().VarChar,"paid").input("ModifiedBy",c().NVarChar,"Kishan Kumar").input("ModifiedOn",c().DateTime,new Date).query(`
            UPDATE Penalty 
            SET Status = @Status, 
                ModifiedBy = @ModifiedBy, 
                ModifiedOn = @ModifiedOn
            WHERE PenaltyId = @PenaltyId
          `),await l.commit(),d.A.info(`Payment created successfully for IssueId: ${t}, StudentId: ${r}`),i.NextResponse.json({message:"Payment created successfully"})}catch(e){return await l.rollback(),d.A.error("Transaction failed during payment creation",{error:e.message,stack:e.stack}),i.NextResponse.json({message:`Transaction failed: ${e.message}`},{status:500})}}catch(e){return d.A.error("Error creating payment",{error:e.message,stack:e.stack}),i.NextResponse.json({message:`Error creating payment: ${e.message}`},{status:500})}}let y=new a.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/penalty/route",pathname:"/api/penalty",filename:"route",bundlePath:"app/api/penalty/route"},resolvedPagePath:"C:\\Users\\Windows\\Desktop\\New Projetct\\library-management-system\\src\\app\\api\\penalty\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:f,workUnitAsyncStorage:x,serverHooks:O}=y;function g(){return(0,o.patchFetch)({workAsyncStorage:f,workUnitAsyncStorage:x})}},51455:e=>{"use strict";e.exports=require("node:fs/promises")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},56285:(e,t,r)=>{"use strict";let s;r.d(t,{X:()=>u});var a=r(16332),n=r.n(a),o=r(97329);r.n(o)().config();let i={user:process.env.DB_USER,password:process.env.DB_PASSWORD,server:process.env.DB_SERVER,database:process.env.DB_NAME,port:parseInt(process.env.DB_PORT||"1433"),options:{trustServerCertificate:!0,enableArithAbort:!0,encrypt:!0},pool:{max:10,min:0,idleTimeoutMillis:3e4}},u=async()=>{if(!s){console.log("Connecting to DB with config:",{user:i.user,server:i.server,database:i.database,port:i.port});try{s=await n().connect(i),console.log("✅ DB Connected successfully")}catch(e){throw console.error("❌ DB connection error:",e),e}}return s}},57075:e=>{"use strict";e.exports=require("node:stream")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},73024:e=>{"use strict";e.exports=require("node:fs")},73136:e=>{"use strict";e.exports=require("node:url")},74075:e=>{"use strict";e.exports=require("zlib")},76760:e=>{"use strict";e.exports=require("node:path")},77598:e=>{"use strict";e.exports=require("node:crypto")},78335:()=>{},78474:e=>{"use strict";e.exports=require("node:events")},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},79743:(e,t,r)=>{"use strict";r.d(t,{A:()=>o});var s=r(91728),a=r.n(s);let n=a().createLogger({levels:{error:0,warn:1,info:2,debug:3},level:"error",format:a().format.combine(a().format.timestamp({format:"YYYY-MM-DD HH:mm:ss"}),a().format.errors({stack:!0}),a().format.printf(({timestamp:e,level:t,message:r,stack:s})=>`${e} [${t.toUpperCase()}] ${r}${s?"\n"+s:""}`)),transports:[new(a()).transports.File({filename:"logs/error.log",level:"error"}),new(a()).transports.File({filename:"logs/combined.log",level:"info"}),new(a()).transports.Console({level:"debug",format:a().format.combine(a().format.colorize(),a().format.simple())})],exceptionHandlers:[new(a()).transports.File({filename:"logs/exceptions.log"})],rejectionHandlers:[new(a()).transports.File({filename:"logs/rejections.log"})]});n.on("error",e=>{console.error("Logger error:",e)});let o=n},81115:e=>{"use strict";e.exports=require("constants")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[447,580,281],()=>r(48780));module.exports=s})();