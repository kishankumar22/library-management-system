(()=>{var e={};e.id=326,e.ids=[326],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},14985:e=>{"use strict";e.exports=require("dns")},19185:e=>{"use strict";e.exports=require("dgram")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29557:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>y,routeModule:()=>m,serverHooks:()=>I,workAsyncStorage:()=>x,workUnitAsyncStorage:()=>f});var s={};t.r(s),t.d(s,{GET:()=>l});var o=t(96559),i=t(48088),n=t(37719),a=t(32190),u=t(56285),p=t(79743),c=t(16332),d=t.n(c);async function l(e){let{searchParams:r}=new URL(e.url);try{let e=r.get("issueId"),t=await (0,u.X)();if(!t)throw Error("Failed to establish database connection");let s=`
      SELECT TOP (1000)
        lp.PaymentId,
        lp.IssueId,
        lp.AmountPaid,
        lp.PaymentMode,
        lp.TransactionId,
        lp.CreatedBy,
        lp.CreatedOn,
        
        -- Book Information
        ISNULL(b.Title, 'N/A') AS BookTitle,
        ISNULL(b.price, 0) AS price,
        
        -- Student Information  
        ISNULL((s.fName + ' ' + s.lName), 'N/A') AS StudentName,
        
        -- Course Information
        ISNULL(c.courseName, 'N/A') AS CourseName,
        ISNULL(sad.courseYear, 'N/A') AS courseYear,
        
        -- Penalty Information
        ISNULL(p.TotalPenalty, 0) AS PenaltyAmount,
        pr.Remarks
        
      FROM LibraryPayment lp WITH (NOLOCK)
      
      -- Basic joins
      LEFT JOIN BookIssue bi WITH (NOLOCK) ON lp.IssueId = bi.IssueId
      LEFT JOIN Books b WITH (NOLOCK) ON bi.BookId = b.BookId
      
      -- Student chain (Updated based on your FK change)
      LEFT JOIN StudentAcademicDetails sad WITH (NOLOCK) ON lp.StudentId = sad.id
      LEFT JOIN Student s WITH (NOLOCK) ON sad.studentId = s.id
      LEFT JOIN Course c WITH (NOLOCK) ON s.courseId = c.id
      
      -- Penalty information
      LEFT JOIN (
        SELECT IssueId, SUM(Amount) AS TotalPenalty 
        FROM Penalty WITH (NOLOCK)
        GROUP BY IssueId
      ) p ON lp.IssueId = p.IssueId
      
      OUTER APPLY (
        SELECT TOP 1 Remarks 
        FROM Penalty WITH (NOLOCK)
        WHERE IssueId = lp.IssueId 
        ORDER BY CreatedOn DESC
      ) pr
    `,o=t.request();if(e){let r=parseInt(e,10);isNaN(r)||(s+=" WHERE lp.IssueId = @IssueId",o.input("IssueId",d().Int,r))}s+=" ORDER BY lp.CreatedOn DESC";let i=await o.query(s);if(!i.recordset||0===i.recordset.length)return a.NextResponse.json({message:"No payment data found",debug:{issueId:e,queryExecuted:!0}},{status:404});return a.NextResponse.json(i.recordset)}catch(e){return p.A.error("Error fetching library payment history",{error:e.message,stack:e.stack,details:{issueId:r.get("issueId"),timestamp:new Date().toISOString()}}),a.NextResponse.json({message:"Error fetching library payment history",details:e.message},{status:500})}}let m=new o.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/library-payment/route",pathname:"/api/library-payment",filename:"route",bundlePath:"app/api/library-payment/route"},resolvedPagePath:"C:\\Users\\Windows\\Desktop\\New Projetct\\library-management-system\\src\\app\\api\\library-payment\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:x,workUnitAsyncStorage:f,serverHooks:I}=m;function y(){return(0,n.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:f})}},31421:e=>{"use strict";e.exports=require("node:child_process")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37067:e=>{"use strict";e.exports=require("node:http")},38522:e=>{"use strict";e.exports=require("node:zlib")},41204:e=>{"use strict";e.exports=require("string_decoder")},44708:e=>{"use strict";e.exports=require("node:https")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},48161:e=>{"use strict";e.exports=require("node:os")},51455:e=>{"use strict";e.exports=require("node:fs/promises")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},56285:(e,r,t)=>{"use strict";let s;t.d(r,{X:()=>u});var o=t(16332),i=t.n(o),n=t(97329);t.n(n)().config();let a={user:process.env.DB_USER,password:process.env.DB_PASSWORD,server:process.env.DB_SERVER,database:process.env.DB_NAME,port:parseInt(process.env.DB_PORT||"1433"),options:{trustServerCertificate:!0,enableArithAbort:!0,encrypt:!0},pool:{max:10,min:0,idleTimeoutMillis:3e4}},u=async()=>{if(!s){console.log("Connecting to DB with config:",{user:a.user,server:a.server,database:a.database,port:a.port});try{s=await i().connect(a),console.log("✅ DB Connected successfully")}catch(e){throw console.error("❌ DB connection error:",e),e}}return s}},57075:e=>{"use strict";e.exports=require("node:stream")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},73024:e=>{"use strict";e.exports=require("node:fs")},73136:e=>{"use strict";e.exports=require("node:url")},74075:e=>{"use strict";e.exports=require("zlib")},76760:e=>{"use strict";e.exports=require("node:path")},77598:e=>{"use strict";e.exports=require("node:crypto")},78335:()=>{},78474:e=>{"use strict";e.exports=require("node:events")},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},79743:(e,r,t)=>{"use strict";t.d(r,{A:()=>m});var s=t(91728),o=t.n(s),i=t(33873),n=t.n(i),a=t(29021),u=t.n(a);let p=n().join(process.cwd(),"logs");u().existsSync(p)||u().mkdirSync(p,{recursive:!0});let c=o().format.combine(o().format.timestamp({format:"YYYY-MM-DD HH:mm:ss"}),o().format.errors({stack:!0}),o().format.json()),d=o().format.combine(o().format.timestamp({format:"HH:mm:ss"}),o().format.errors({stack:!0}),o().format.colorize(),o().format.printf(({timestamp:e,level:r,message:t,stack:s,...o})=>{let i=Object.keys(o).length?`
${JSON.stringify(o,null,2)}`:"";return`${e} [${r.toUpperCase()}] ${t}${s?"\n"+s:""}${i}`})),l=o().createLogger({levels:{error:0,warn:1,info:2,debug:3},level:"debug",defaultMeta:{service:"library-management",environment:"production"},transports:[new(o()).transports.File({filename:n().join(p,"error.log"),level:"error",format:c,maxsize:5242880,maxFiles:5}),new(o()).transports.File({filename:n().join(p,"info.log"),level:"info",format:c,maxsize:5242880,maxFiles:5}),new(o()).transports.File({filename:n().join(p,"combined.log"),format:c,maxsize:5242880,maxFiles:5}),new(o()).transports.Console({level:"debug",format:d})],exceptionHandlers:[new(o()).transports.File({filename:n().join(p,"exceptions.log"),format:c,maxsize:5242880,maxFiles:3})],rejectionHandlers:[new(o()).transports.File({filename:n().join(p,"rejections.log"),format:c,maxsize:5242880,maxFiles:3})]});l.on("error",e=>{console.error("Logger error:",e)});let m={error:(e,r)=>l.error(e,r),warn:(e,r)=>l.warn(e,r),info:(e,r)=>l.info(e,r),debug:(e,r)=>l.debug(e,r),apiRequest:(e,r,t,s)=>{l.info(`API ${e} ${r}${t?` - ${t}`:""}`,{type:"api_request",method:e,url:r,statusCode:t,...s})},apiError:(e,r,t,s)=>{l.error(`API ${e} ${r} - Error: ${t.message}`,{type:"api_error",method:e,url:r,error:t.message,stack:t.stack,...s})},dbQuery:(e,r,t)=>{l.debug(`DB Query: ${e}${r?` (${r}ms)`:""}`,{type:"db_query",query:e,duration:r,...t})},userAction:(e,r,t)=>{l.info(`User ${e} performed: ${r}`,{type:"user_action",userId:e,action:r,...t})},fileOperation:(e,r,t,s)=>{l[t?"info":"error"](`File ${e}: ${r} - ${t?"Success":"Failed"}`,{type:"file_operation",operation:e,filename:r,success:t,...s})}}},81115:e=>{"use strict";e.exports=require("constants")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[447,580,281],()=>t(29557));module.exports=s})();