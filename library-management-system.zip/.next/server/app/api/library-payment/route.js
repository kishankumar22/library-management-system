(()=>{var e={};e.id=326,e.ids=[326],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},16141:e=>{"use strict";e.exports=require("node:zlib")},19185:e=>{"use strict";e.exports=require("dgram")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29557:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>y,routeModule:()=>m,serverHooks:()=>O,workAsyncStorage:()=>I,workUnitAsyncStorage:()=>x});var s={};t.r(s),t.d(s,{GET:()=>d});var o=t(96559),i=t(48088),n=t(37719),a=t(32190),u=t(56285),p=t(79743),c=t(16332),l=t.n(c);async function d(e){let{searchParams:r}=new URL(e.url);try{let e,t=r.get("issueId"),s=t?parseInt(t,10):null;if(t&&isNaN(s))throw Error("Invalid IssueId parameter. Must be a valid number.");let o=await (0,u.X)();if(!o)throw Error("Failed to establish database connection");if(!(e=null!==s?await o.request().input("IssueId",l().Int,s).query(`
          SELECT TOP (1000)
            lp.PaymentId,
            b.Title AS BookTitle,
            s.fName + ' ' + s.lName AS StudentName,
            c.courseName AS CourseName,
            lp.AmountPaid,
            lp.PaymentMode,
            lp.TransactionId,
            lp.CreatedBy,
            lp.CreatedOn,
            lp.IssueId
          FROM LibraryPayment lp WITH (NOLOCK)
          LEFT JOIN BookIssue bi WITH (NOLOCK) ON lp.IssueId = bi.IssueId
          LEFT JOIN Books b WITH (NOLOCK) ON bi.BookId = b.BookId
          LEFT JOIN Student s WITH (NOLOCK) ON bi.StudentId = s.id
          LEFT JOIN Course c WITH (NOLOCK) ON s.courseId = c.id
          WHERE lp.IssueId = @IssueId
          ORDER BY lp.CreatedOn DESC
        `):await o.request().query(`
          SELECT TOP (1000)
            lp.PaymentId,
            b.Title AS BookTitle,
            b.price,
            s.fName + ' ' + s.lName AS StudentName,
            c.courseName AS CourseName,
            lp.AmountPaid,
            lp.PaymentMode,
            lp.TransactionId,
            lp.CreatedBy,
            lp.CreatedOn,
            lp.IssueId,
            ISNULL(p.TotalPenalty, 0) AS PenaltyAmount,
            pr.Remarks
          FROM LibraryPayment lp WITH (NOLOCK)
          LEFT JOIN BookIssue bi WITH (NOLOCK) ON lp.IssueId = bi.IssueId
          LEFT JOIN Books b WITH (NOLOCK) ON bi.BookId = b.BookId
          LEFT JOIN Student s WITH (NOLOCK) ON bi.StudentId = s.id
          LEFT JOIN Course c WITH (NOLOCK) ON s.courseId = c.id
          LEFT JOIN (
            SELECT IssueId, SUM(Amount) AS TotalPenalty 
            FROM Penalty
            GROUP BY IssueId
          ) p ON lp.IssueId = p.IssueId
          OUTER APPLY (
            SELECT TOP 1 Remarks 
            FROM Penalty 
            WHERE IssueId = lp.IssueId 
            ORDER BY CreatedOn DESC
          ) pr
          ORDER BY lp.CreatedOn DESC;
        `)).recordset||0===e.recordset.length)return a.NextResponse.json({message:"No payment data found"},{status:404});return a.NextResponse.json(e.recordset)}catch(e){return p.A.error("Error fetching library payment history",{error:e.message,stack:e.stack,details:{issueId:r.get("issueId"),timestamp:new Date().toISOString()}}),a.NextResponse.json({message:"Error fetching library payment history",details:e.message},{status:500})}}let m=new o.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/library-payment/route",pathname:"/api/library-payment",filename:"route",bundlePath:"app/api/library-payment/route"},resolvedPagePath:"C:\\Users\\Windows\\Desktop\\New Projetct\\library-management-system\\src\\app\\api\\library-payment\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:I,workUnitAsyncStorage:x,serverHooks:O}=m;function y(){return(0,n.patchFetch)({workAsyncStorage:I,workUnitAsyncStorage:x})}},31421:e=>{"use strict";e.exports=require("node:child_process")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37067:e=>{"use strict";e.exports=require("node:http")},37366:e=>{"use strict";e.exports=require("dns")},41204:e=>{"use strict";e.exports=require("string_decoder")},44708:e=>{"use strict";e.exports=require("node:https")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},48161:e=>{"use strict";e.exports=require("node:os")},51455:e=>{"use strict";e.exports=require("node:fs/promises")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},56285:(e,r,t)=>{"use strict";let s;t.d(r,{X:()=>u});var o=t(16332),i=t.n(o),n=t(97329);t.n(n)().config();let a={user:process.env.DB_USER,password:process.env.DB_PASSWORD,server:process.env.DB_SERVER,database:process.env.DB_NAME,port:parseInt(process.env.DB_PORT||"1433"),options:{trustServerCertificate:!0,enableArithAbort:!0,encrypt:!0},pool:{max:10,min:0,idleTimeoutMillis:3e4}},u=async()=>{if(!s){console.log("Connecting to DB with config:",{user:a.user,server:a.server,database:a.database,port:a.port});try{s=await i().connect(a),console.log("✅ DB Connected successfully")}catch(e){throw console.error("❌ DB connection error:",e),e}}return s}},57075:e=>{"use strict";e.exports=require("node:stream")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},73024:e=>{"use strict";e.exports=require("node:fs")},73136:e=>{"use strict";e.exports=require("node:url")},74075:e=>{"use strict";e.exports=require("zlib")},76760:e=>{"use strict";e.exports=require("node:path")},77598:e=>{"use strict";e.exports=require("node:crypto")},78335:()=>{},78474:e=>{"use strict";e.exports=require("node:events")},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},79743:(e,r,t)=>{"use strict";t.d(r,{A:()=>n});var s=t(91728),o=t.n(s);let i=o().createLogger({levels:{error:0,warn:1,info:2,debug:3},level:"error",format:o().format.combine(o().format.timestamp({format:"YYYY-MM-DD HH:mm:ss"}),o().format.errors({stack:!0}),o().format.printf(({timestamp:e,level:r,message:t,stack:s})=>`${e} [${r.toUpperCase()}] ${t}${s?"\n"+s:""}`)),transports:[new(o()).transports.File({filename:"logs/error.log",level:"error"}),new(o()).transports.File({filename:"logs/combined.log",level:"info"}),new(o()).transports.Console({level:"debug",format:o().format.combine(o().format.colorize(),o().format.simple())})],exceptionHandlers:[new(o()).transports.File({filename:"logs/exceptions.log"})],rejectionHandlers:[new(o()).transports.File({filename:"logs/rejections.log"})]});i.on("error",e=>{console.error("Logger error:",e)});let n=i},81115:e=>{"use strict";e.exports=require("constants")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[447,580,281],()=>t(29557));module.exports=s})();