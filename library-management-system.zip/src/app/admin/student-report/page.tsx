'use client';

export default function StudentReportPage() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">Student Report</h1>
      <p className="text-gray-600">Generate or View Student Reports</p>
    </main>
  );
}
